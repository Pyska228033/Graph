#ifndef RUB_H
#define RUB_H

#include <iostream>
#include <vector>


template<class T>
class Edge
{
public:
	T ferst;
	T second;
};


#endif // !RUB_H
