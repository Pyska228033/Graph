#ifndef GRAPH_H
#define GRAPH_H

#include "Edge.h"
#include <queue>
#include <stack>

using namespace std;

template <class T>
class Graph
{
private:

	vector<vector<T> > Matrix;
	vector<T> names;
	int size;

public:
	Graph();
	Graph(vector<Edge<T>> edges, int n);
	void Insert(Edge<T>& edge);
	void Delet(T key);
	void BFS(T start, T end);
	void DFS(T start);
	void printGraph();
};

template < class T>
Graph<T>::Graph()
{

}

template<class T>
Graph<T>::Graph(vector<Edge<T>>edges, int n)
{
	Matrix.resize(n);
	this->size = n;
	names.resize(size);

	for (Edge<T> edge : edges)
	{

		names[edge.ferst] = edge.ferst;
		for(int i = 0; i < size; i++)
			if(names[i] != edge.second )
				names[edge.second] = edge.second;

		if (Matrix[edge.ferst].size() > 0)
		for (T v : Matrix[edge.ferst])
		{
			if (v != edge.second)
			{
				Matrix[edge.ferst].push_back(edge.second);
				break;
			}
		}
		else Matrix[edge.ferst].push_back(edge.second);

		if(Matrix[edge.second].size() > 0)
		for (T v : Matrix[edge.second])
		{
			if (v != edge.ferst && edge.second != NULL)
			{
				Matrix[edge.second].push_back(edge.ferst);
				break;
			}
		}

		else if(edge.second != NULL)
			Matrix[edge.second].push_back(edge.ferst);
	}
}

template<class T>
void Graph<T>::Insert(Edge<T>& edge)
{
	Matrix.resize(size+1);
	size++;
	names.resize(size);
	names[edge.ferst] = edge.ferst;

		for(int i = 0; i < size; i++)
			if(names[i] != edge.second )
				names[edge.second] = edge.second;

		if (Matrix[edge.ferst].size() > 0)
			for (T v : Matrix[edge.ferst])
			{
				if (v != edge.second)
				{
					Matrix[edge.ferst].push_back(edge.second);
					break;
				}
			}
		else Matrix[edge.ferst].push_back(edge.second);

		if (Matrix[edge.second].size() > 0)
			for (T v : Matrix[edge.second])
			{
				if (v != edge.ferst && edge.second != NULL)
				{
					Matrix[edge.second].push_back(edge.ferst);
					break;
				}
			}

		else if (edge.second != NULL)
			Matrix[edge.second].push_back(edge.ferst);
	
	
}

template <class T>
void Graph<T>::Delet(T key)
{
	for (T i : Matrix[key])
	{
		int n = 0;
		for (T j : Matrix[i])
		{
			n++;
			if (j == key)
			{
				Matrix[i].erase(Matrix[i].begin() + n - 1);
			}
		}
	}

	for (int i = key; i < size - 1; i++)
	{
		Matrix[i] = Matrix[i + 1];
	}

	//vector<T>().swap(Matrix[key]);
	names.erase(names.begin() + key);
	size--;
}

template < class T>
void Graph<T>::BFS(T start, T end)
{
	queue<T> spis;
	vector<bool> discovered(size);

	discovered[start] = true;
	spis.push(start);
	
	while (!spis.empty())
	{
		T i = spis.front();
		cout << i << " ";
		spis.pop();

		for (T index : Matrix[i])
		{
			if (discovered[index] != true && index != end)
			{
				discovered[index] = true;
				spis.push(index);
			}
			else if (index == end)
			{
				discovered[index] = true;
				while (!spis.empty())
					spis.pop();
				break;
			}
		}
	}

	if (discovered[end] != true)
		cout << "Element not found"<< endl;
	else
	{
		stack<T> Way;
		cout << "Way: ";
		discovered[end] = false;
		T index = end;
		while (index != start)
		{
			for (T i : Matrix[index])
			{
				if (discovered[i] == true)
				{
					discovered[i] = false;
					Way.push(i);
					index = i;
					break;
				}
			}
		}
		while (!Way.empty())
		{
			cout << Way.top() << " -> ";
			Way.pop();
		}
		cout << end;

	}
	cout << endl;
}

template <class T>
void Graph<T>::DFS(T start)
{
	vector<bool> discovered(size);
	stack<T> spis;

	discovered[start] = true;
	spis.push(start);

	while (!spis.empty())
	{
		T i = spis.top();
		cout << i << " ";
		spis.pop();

		for (T index : Matrix[i])
		{
			if (discovered[index] != true)
			{
				discovered[index] = true;
				spis.push(index);
			}
		}
	}
	cout << endl;

}

template<class T>
void Graph<T>::printGraph()
{
	for (int i = 0; i < this->size; i++)
	{
		if(names[i] != NULL)
		cout << names[i] << "-->";

		for (T v : Matrix[i]) 
		{
			if(v!=NULL)
			cout << v << " ";
		}
		cout << endl;
	}
}

#endif // !GRAPH_H

